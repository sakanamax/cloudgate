/******************************************************/
/*         Autorun for Simulation and sorting         */ 
/*     Simulation : parameterized GATE Simulation     */
/*                    Date: 2016.7                    */
/*                Author : PoChia Huang               */
/*             gcc -o AUTORUN autorun.c -lm           */
/******************************************************/

/******************************************************/
/* Note:                                              */
/* The total event number must smller than 10^6       */
/* The sorted image have been rotated with 90 degree  */
/******************************************************/
/* Two output file :                                  */
/*  1. Energy deposit data                            */
/*  2. Photon counting data                           */
/******************************************************/
/* Output format:                                     */
/*  1. 1080 x 1440 x 1                                */
/*  2. 32-Bits real                                   */
/******************************************************/ 

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Gate Simualtion Related
#define SID 650

// Sorting Related
#define DetNumX 1080
#define DetNumY 1440
#define Size_Per_Event 45

void check(int angle, int number){

  int i;

  char IFileName_1[256];
  char IFileName_2[256];
  char IFileName_3[256];

  char IFileName[256];

  char IllegalFileName[256] = "Illegal_File.txt";

  FILE *fp_1, *fp_2, *fp_3;

  FILE *fp_ill;
  

  int size_1, size_2, size_3;
  int size_chk;

  float Top_Size;
  float Bottom_Size;

  sprintf(IFileName_1, "./Result/Tomo_%03d_0000.dat", angle);
  sprintf(IFileName_2, "./Result/Tomo_%03d_0001.dat", angle);
  sprintf(IFileName_3, "./Result/Tomo_%03d_0002.dat", angle);
  fp_1 = fopen(IFileName_1, "r");
  fp_2 = fopen(IFileName_2, "r");
  fp_3 = fopen(IFileName_3, "r");
  fseek(fp_1, 0, SEEK_END);
  fseek(fp_2, 0, SEEK_END);
  fseek(fp_3, 0, SEEK_END);
  size_1 = ftell(fp_1);
  size_2 = ftell(fp_2);
  size_3 = ftell(fp_3);
  fseek(fp_1, 0, SEEK_SET);
  fseek(fp_2, 0, SEEK_SET);
  fseek(fp_3, 0, SEEK_SET);

  if((size_2 <= size_1 && size_1 <= size_3) || (size_3 <= size_1 && size_1 <= size_2)){
    printf("\"%d\", %d, %d\n", size_1, size_2, size_3);
    Bottom_Size = size_1 * 0.75;
    Top_Size = size_1 * 1.25;
    printf("%7.3f, %7.3f\n", Top_Size, Bottom_Size);
  }else if((size_1 <= size_2 && size_2 <= size_3) || (size_3 <= size_2 && size_2 <= size_1)){
    printf("%d, \"%d\", %d\n", size_1, size_2, size_3);
    Bottom_Size = size_2 * 0.75;
    Top_Size = size_2 * 1.25;
    printf("%7.3f, %7.3f\n", Top_Size, Bottom_Size);
  }else{
    printf("%d, %d, \"%d\"\n", size_1, size_2, size_3);
    Bottom_Size = size_3 * 0.75;
    Top_Size = size_3 * 1.25;
    printf("%7.3f, %7.3f\n", Top_Size, Bottom_Size);
  }

  fp_ill = fopen(IllegalFileName, "w");
  for(i=0;i<number;i++){
    printf("%d\n", i);
    sprintf(IFileName, "./Result/Tomo_%03d_%04d.dat", angle, i);
    FILE *fp_chk;
    if((fp_chk = fopen(IFileName, "r")) == NULL){
      fprintf(fp_ill, "%s not exist\n", IFileName);
      exit(1);
    }else{
      fseek(fp_chk, 0, SEEK_END);
      size_chk = ftell(fp_chk);
      fseek(fp_chk, 0, SEEK_SET);
    }
    if(size_chk % Size_Per_Event != 0 || size_chk > Top_Size || size_chk < Bottom_Size){
      fprintf(fp_ill, "%s\n", IFileName);
    }
    fclose(fp_chk);
  }
  fclose(fp_ill);
}


int main(int argc,char **argv){

  if(argc != 4){
    printf("\nUSAGE : \n");
    printf(" %s [Projection Angle (integer with unit degree)] [First Projection Angle] [The Number of Gate Simuation]\n\n", argv[0]);
    exit(1);
  }

  int i,j;

  char OFileName[64];
  char Command[512];
  char ASCII_OFileName[64];

  int angle = atoi(argv[1]);
  int start = atoi(argv[2]);
  int number = atoi(argv[3]);

  // GATE Simulation (Parameterized Gate)
  // Source Position Variable : at Line 66 in source_W_Rh_28.mac
  // Output Variable : at Line 6 in output.mac
  double SourcePosX;
  double SourcePosZ;
  double PosShiftX = 0.0;
  double PosShiftZ = -350.0;
  SourcePosX = -SID * cos(angle * M_PI / 180.0) + PosShiftX;
  SourcePosZ = SID * sin(angle * M_PI / 180.0) + PosShiftZ;
  for(i=start;i<number;i++){
    sprintf(ASCII_OFileName, "Output/Tomosynthesis_%03d_", angle);
    sprintf(Command, "Gate -a [SourcePosX,%.8f][SourcePosZ,%.8f][Output_FileName,%s] Tomosynthesis.mac", SourcePosX, SourcePosZ, ASCII_OFileName);
    printf("[Gate Simulation %03d] : %s\n", i, Command);
    system(Command);
    sprintf(OFileName, "./Result/Tomo_%03d_%04d.dat", angle, i);
    sprintf(ASCII_OFileName, "./Output/Tomosynthesis_%03d_Singles.dat", angle);
    sprintf(Command, "mv %s %s", ASCII_OFileName, OFileName);
    printf("[Move Result %03d] : %s\n", i, Command);
    system(Command);
  }

  // Sort ASCII to image (photon counting and energy deposit) (90 degree rotating)
  int size = 0;
  char IFileName[64];
  char cluster_tmp[6];
  char pixel_tmp[6];
  char energy_tmp[12];  
  unsigned short int raw;
  unsigned short int column;
  float energy;  
  float *photon_counting_proj;
  float *energy_deposit_proj;
  photon_counting_proj = (float *)malloc(DetNumX * DetNumY * sizeof(float));
  energy_deposit_proj = (float *)malloc(DetNumX * DetNumY * sizeof(float));
  for(i=0;i<DetNumX * DetNumY;i++){
    *(photon_counting_proj + i) = 0.0;
    *(energy_deposit_proj + i) = 0.0;
  }
  
  check(angle, number);
  printf("Check passed!!\n");

  for(i=0;i<number;i++){
    sprintf(IFileName, "./Result/Tomo_%03d_%04d.dat", angle, i);
    FILE *fp;
    if((fp = fopen(IFileName, "r")) == NULL){
      printf("File %s Open Error", IFileName);
      exit(1);
    }else{
      fseek(fp, 0, SEEK_END);
      size = ftell(fp);
      fseek(fp, 0, SEEK_SET);
      if(size % Size_Per_Event != 0){
	printf("File Size Error...\n");
	exit(1);
      }
      printf("\"%s\" : %d Bytes. Contains %d Events\n", IFileName, size, size/Size_Per_Event);
      for(j=0;j<size/Size_Per_Event;j++){
	fseek(fp, 21 + j * Size_Per_Event, SEEK_SET);
	fread(cluster_tmp, sizeof(char), 6, fp);
	fseek(fp, 27 + j * Size_Per_Event, SEEK_SET);
	fread(pixel_tmp, sizeof(char), 6, fp);
	fseek(fp, 33 + j * Size_Per_Event, SEEK_SET);
	fread(energy_tmp, sizeof(char), 12, fp);
	raw = atoi(cluster_tmp);
	column = atoi(pixel_tmp);
	energy = atof(energy_tmp);
	*(photon_counting_proj + raw * DetNumX + column) += 1.0; 
	*(energy_deposit_proj + raw * DetNumX + column) += energy; 
      }
      fclose(fp);
    }
  }
  FILE *photon_counting_output;
  FILE *energy_deposit_output;
  char photon_counting_filename[2048];
  char energy_deposit_filename[2048];
  sprintf(photon_counting_filename, "./Result/Tomo_%03d_10GBq_PhotonCounting.proj", angle);
  sprintf(energy_deposit_filename, "./Result/Tomo_%03d_10GBq_EnergyDeposit.proj", angle);
  photon_counting_output = fopen(photon_counting_filename, "w");
  energy_deposit_output = fopen(energy_deposit_filename, "w");
  fwrite(photon_counting_proj, sizeof(float), DetNumX * DetNumY, photon_counting_output);
  fwrite(energy_deposit_proj, sizeof(float), DetNumX * DetNumY, energy_deposit_output);
  fclose(photon_counting_output);
  fclose(energy_deposit_output);
  
  free(photon_counting_proj);
  free(energy_deposit_proj);

  return 0;
}

 
