#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char **argv){

  if(argc != 5){
    printf("\n USAGE: %s [1st Angle(int)] [Last Angle(int)] [First output index] [Total simulation number]\n", argv[0]);
    printf(" EXAMPLE: 1000 simulations from angle 60 to 79 -> %s 60 79 0 1000\n", argv[0]);
    printf(" NOTE: if the last two terms are the same, merge only\n\n");
    exit(1);
  }

  int i;

  int first = atoi(argv[1]);
  int last = atoi(argv[2]);
  char command[256];
  int first_index = atoi(argv[3]);
  int number = atoi(argv[4]);

  for(i=first;i<=last;i++){
    sprintf(command, "nohup ./AUTORUN %d %d %d > nohup_%03d.out &", i, first_index, number, i);
    printf("%s\n", command);
    system(command);
    sleep(2);
  }

  return 0;
}



